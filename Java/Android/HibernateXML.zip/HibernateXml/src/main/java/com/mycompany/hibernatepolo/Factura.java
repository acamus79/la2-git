package com.mycompany.hibernatepolo;



public class Factura {
    
   private int num_factura;
   private String descripcion_factura;

  
   public Factura()
   {
   
   }

    public int getNum_factura() {
        return num_factura;
    }

    public void setNum_factura(int num_factura) {
        this.num_factura = num_factura;
    }

    public String getDescripcion() {
        return descripcion_factura;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion_factura = descripcion;
    }
  


   
}
 


   

        

    